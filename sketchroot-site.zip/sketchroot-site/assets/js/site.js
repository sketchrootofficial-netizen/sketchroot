/* SketchRoot: navigation behaviour. No dependencies, no tracking.
   Every link in the menus exists in the HTML, so the site is fully crawlable
   and usable with JavaScript switched off. */
(function () {
  var nav = document.querySelector('.nav');
  var btn = document.querySelector('.menu-btn');
  var dds = document.querySelectorAll('.dd');

  function closeDropdowns(except) {
    dds.forEach(function (dd) {
      if (dd === except) return;
      dd.classList.remove('open');
      var b = dd.querySelector('.dd-btn');
      if (b) b.setAttribute('aria-expanded', 'false');
    });
  }

  if (btn && nav) {
    btn.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  dds.forEach(function (dd) {
    var b = dd.querySelector('.dd-btn');
    if (!b) return;
    b.addEventListener('click', function () {
      var open = dd.classList.toggle('open');
      b.setAttribute('aria-expanded', open ? 'true' : 'false');
      closeDropdowns(dd);
    });
  });

  document.addEventListener('click', function (e) {
    if (!e.target.closest('.dd')) closeDropdowns();
    if (nav && nav.classList.contains('open') && !e.target.closest('.nav')) {
      nav.classList.remove('open');
      if (btn) btn.setAttribute('aria-expanded', 'false');
    }
  });

  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    closeDropdowns();
    if (nav) nav.classList.remove('open');
    if (btn) btn.setAttribute('aria-expanded', 'false');
  });

  // close the mobile panel after choosing an in page link
  document.querySelectorAll('.navlinks a').forEach(function (a) {
    a.addEventListener('click', function () {
      if (nav) nav.classList.remove('open');
      if (btn) btn.setAttribute('aria-expanded', 'false');
    });
  });
})();
